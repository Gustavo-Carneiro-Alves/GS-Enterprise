package br.com.fiap.model;

import br.com.fiap.anotacao.Tabela;

@Tabela(nome = "TAB_ALUNO")
public class Aluno {
	
}