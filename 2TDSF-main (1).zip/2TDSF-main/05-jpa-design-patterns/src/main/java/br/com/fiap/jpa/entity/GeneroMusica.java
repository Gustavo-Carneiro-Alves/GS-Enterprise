package br.com.fiap.jpa.entity;

public enum GeneroMusica {

	POP, MPB, TRAP,
	ELETRONICO, ROCK
	
}
