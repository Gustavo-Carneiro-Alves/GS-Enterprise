package br.com.fiap.jpa.entity;

public enum StatusPedido {

	CANCELADO, ANDAMENTO, AGUARDANDO_PAGAMENTO, TRANSPORTE, FINALIZADO
	
}