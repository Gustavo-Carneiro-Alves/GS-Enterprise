package br.com.fiap.revisao.model;

//Enum -> conjunto de constantes
public enum Combustivel {

	GASOLINA, ETANOL, FLEX, ELETRICO, DIESEL, HIBRIDO, GNV, GASOLINA_ADITIVADA
	
}