package br.com.fiap.jpa.entity;

public enum GeneroMusica {

	PAGODE, ROCK, POP, FUNK, SERTANEJO, MPB, SAMBA
	
}