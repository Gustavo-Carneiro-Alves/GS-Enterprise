package br.fiap.com.main;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;

import br.com.fiap.dao.CidadeDao;
import br.com.fiap.dao.ClienteDao;
import br.com.fiap.dao.PacoteDao;
import br.com.fiap.dao.TransporteDao;
import br.com.fiap.dao.impl.CidadeDaoImpl;
import br.com.fiap.dao.impl.ClienteDaoImpl;
import br.com.fiap.dao.impl.PacoteDaoImpl;
import br.com.fiap.dao.impl.TransporteDaoImpl;
import br.com.fiap.entity.Cidade;
import br.com.fiap.entity.Cliente;
import br.com.fiap.entity.Transporte;
import br.com.fiap.singleton.EntityManagerFactorySingleton;

public class Pesquisas2 {

	public static void main(String[] args) {
		EntityManagerFactory fabrica = EntityManagerFactorySingleton.getInstance();
		EntityManager em = fabrica.createEntityManager();
		
		// Instanciar o ClienteDao
		ClienteDao clienteDao = new ClienteDaoImpl(em);

		// Exibir o nome de todos os clientes
		List<Cliente> clientes = clienteDao.buscarPorParteNome("A");
		for (Cliente item : clientes) {
			System.out.println(item.getNome());
		}
		
		//Contar a quantidade de clientes do PR
		long qtd = clienteDao.contarPorEstado("BA");
		System.out.println("Quantidade de clientes do estado: " + qtd);
		
		TransporteDao transporteDao = new TransporteDaoImpl(em);
		PacoteDao pacoteDao = new PacoteDaoImpl(em);
		
		Transporte transporte = transporteDao.pesquisar(2);
		
		double total = pacoteDao.somarPrecoPorTransporte(transporte);
		System.out.println("A soma dos pre�os �: " + total);
		
		// Recuperar os clientes que possuem o CPF que come�a com 9
		clientes = clienteDao.buscarPorCpf("99");
		
		for (Cliente cliente : clientes) {
			System.out.println(cliente.getNome() + " " + cliente.getCpf());
		}
		
		//Recuperar a quantidade de clientes por nome de cidade
		List<Object[]> resultado = clienteDao.agruparCidade();
		
		//Exibir a quantidade de clientes e o nome da cidade
		for (Object[] obj : resultado) {
			System.out.println(obj[0] + " - " + obj[1]);
		}
		
		//Instanciar a CidadeDao
		CidadeDao cidadeDao = new CidadeDaoImpl(em);
		
		//Pesquisar as cidades pelo n�mero de habitantes
		List<Cidade> cidades = cidadeDao.buscarPorNumeroHabitantesEntre(100, 1000);
		
		//Exibir o nome da cidade e o n�mero de habitantes
		for (Cidade cidade : cidades) {
			System.out.println(cidade.getNome() + " " + cidade.getNrHabitantes());
		}
		
		em.close();
		fabrica.close();
	}//main
}//class
