package br.fiap.com.main;

import java.util.Arrays;
import java.util.Calendar;
import java.util.GregorianCalendar;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;

import br.com.fiap.dao.ClienteDao;
import br.com.fiap.dao.PacoteDao;
import br.com.fiap.dao.TransporteDao;
import br.com.fiap.dao.impl.ClienteDaoImpl;
import br.com.fiap.dao.impl.PacoteDaoImpl;
import br.com.fiap.dao.impl.TransporteDaoImpl;
import br.com.fiap.entity.Cliente;
import br.com.fiap.entity.Pacote;
import br.com.fiap.entity.Transporte;
import br.com.fiap.singleton.EntityManagerFactorySingleton;

public class Pesquisas {

	public static void main(String[] args) {
		EntityManagerFactory fabrica = EntityManagerFactorySingleton.getInstance();
		EntityManager em = fabrica.createEntityManager();

		//Listar todos os pacotes:
		//Instanciar o PacoteDao
		PacoteDao pacoteDao = new PacoteDaoImpl(em);
		//Chamar o m�todo listar
		//List<Pacote> pacotes = pacoteDao.listar();
		List<Pacote> pacotes = pacoteDao.buscarPorQuantidadeDiasMaior(5);
		
		//Exibir a descri��o dos pacotes
		for (Pacote item : pacotes) {
			System.out.println(item.getDescricao());
		}
		
		//Instanciar o ClienteDao
		ClienteDao clienteDao = new ClienteDaoImpl(em);
		
		//Exibir o nome de todos os clientes
		//List<Cliente> clientes = clienteDao.listar();
		List<Cliente> clientes = clienteDao.buscarPorParteNome("Ma");
		for (Cliente item: clientes) {
			System.out.println(item.getNome());
		}
		
		//Pesquisar pacotes por transporte
		//Instanciar o TransporteDao
		TransporteDao transporteDao = new TransporteDaoImpl(em);
		//Pesquisar um transporte pelo ID
		Transporte transporte = transporteDao.pesquisar(1);
		//Chamar o m�todo pesquisarPorTransporte do PacoteDao, passando o transporte
		pacotes = pacoteDao.buscarPorTransporte(transporte);
		//Exibir a descri�ao do pacote e a empresa do transporte
		for (Pacote p : pacotes) {
			System.out.println(p.getDescricao() + " " + p.getTransporte().getEmpresa());
		}
		
		//Pesquisar os clientes por estado (SP, PR)
		clientes = clienteDao.buscarPorEstado("BA");
		
		//Exibir o nome dos clientes e o estado
		for (Cliente cliente : clientes) {
			System.out.println(cliente.getNome() + " " +
					cliente.getEndereco().getCidade().getUf());
		}
		
		//Pesquisar os clientes por numero de dias de reserva
		clientes = clienteDao.buscarPorNumeroDiasReserva(10);
		
		//Exibir o nome dos clientes
		for (Cliente cliente : clientes) {
			System.out.println(cliente.getNome());
		}
		
		//Listar os 3 primeiros clientes
		for (Cliente cliente : clienteDao.listar(3, 3)) {
			System.out.println(cliente.getNome());
		}
		
		//Criar uma data do tipo calendar
		Calendar inicio = new GregorianCalendar(2024, Calendar.AUGUST, 1);
		Calendar fim = new GregorianCalendar(2024, Calendar.AUGUST, 30);
		
		//Pesquisar pacotes por intervalo de datas
		pacotes = pacoteDao.buscarPorDatas(inicio, fim);
		
		//Exibir a descri��o dos pacotes
		for (Pacote p : pacotes) {
			System.out.println(p.getDescricao());
		}
		
		//Pesquisar os clientes por parte do nome e parte do nome da cidade
		clientes = clienteDao.buscar("Ma", "Sal");
		
		//Exibir o nome e o nome da cidade dos clientes
		for (Cliente c : clientes) {
			System.out.println(c.getNome() + " " 
					+ c.getEndereco().getCidade().getNome());
		}
		
		//Criar a lista de siglas dos estados
		List<String> estados = Arrays.asList(new String[] {"SP", "PR"});
		
		//Pesquisar os clientes por estados
		clientes = clienteDao.buscarPorEstados(estados);
		
		//Exibir o nome e o estado do cliente
		for (Cliente abacaxi : clientes) {
			System.out.println(abacaxi.getNome() + " " +
					abacaxi.getEndereco().getCidade().getUf());
		}
		
	}//main
}//class








