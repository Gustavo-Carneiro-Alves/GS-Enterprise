package br.com.fiap.dao;

import java.util.List;

import br.com.fiap.entity.Cliente;

public interface ClienteDao extends GenericDao<Cliente,Integer>{

	List<Cliente> buscarPorParteNome(String nome);
	
	//4-Buscar por Estado
	List<Cliente> buscarPorEstado(String estado);
	
	//5-Buscar por numero de dias de reserva
	List<Cliente> buscarPorNumeroDiasReserva(Integer qtd);
	
	//7-Buscar por parte do nome e parte do nome da cidade
	List<Cliente> buscar(String nome, String cidade);
	
	//8-Buscar por Estados
	List<Cliente> buscarPorEstados(List<String> estados);
	
	//Contar a quantidade de clientes por estado
	Long contarPorEstado(String estado);
	
	//Buscar pelo come�o do CPF
	List<Cliente> buscarPorCpf(String cpf);
	
	//Retornar a qtd de clientes por nome da cidade
	List<Object[]> agruparCidade();
	
}
