package br.com.fiap.dao.impl;

import java.util.List;

import javax.persistence.EntityManager;

import br.com.fiap.dao.ClienteDao;
import br.com.fiap.entity.Cliente;

public class ClienteDaoImpl extends GenericDaoImpl<Cliente,Integer> implements ClienteDao{

	public ClienteDaoImpl(EntityManager entityManager) {
		super(entityManager);
	}
	
	public Long contarPorEstado(String estado) {
		return em.createQuery("select count(c) from Cliente c where c.endereco.cidade.uf = :e", Long.class)
				.setParameter("e", estado)
				.getSingleResult();
	}

	public List<Cliente> buscarPorParteNome(String nome) {
		return em.createQuery("from Cliente c where lower(c.nome) like lower(:n) order by c.nome", Cliente.class)
				.setParameter("n", "%" + nome + "%")
				.getResultList();
	}

	public List<Cliente> buscarPorEstado(String estado) {
		return em.createQuery("from Cliente c where c.endereco.cidade.uf = :churros", Cliente.class)
				.setParameter("churros", estado)
				.getResultList();
	}

	public List<Cliente> buscarPorNumeroDiasReserva(Integer qtd) {
		return em.createQuery("select r.cliente from Reserva r where r.numeroDias = :d", Cliente.class)
				.setParameter("d", qtd)
				.setMaxResults(2) //M�ximo de resultados
				.getResultList();
	}

	public List<Cliente> buscar(String nome, String cidade) {
		return em.createQuery("from Cliente c where c.nome like :churros and "
				+ "c.endereco.cidade.nome like :abacaxi",Cliente.class)
				.setParameter("churros", "%" + nome + "%")
				.setParameter("abacaxi", "%" + cidade + "%")
				.getResultList();
	}

	public List<Cliente> buscarPorEstados(List<String> estados) {
		return em.createQuery("from Cliente c where c.endereco.cidade.uf in :e", Cliente.class)
				.setParameter("e", estados)
				.getResultList();
	}

	public List<Cliente> buscarPorCpf(String cpf) {
		return em.createNamedQuery("Cliente.porCpf", Cliente.class)
				.setParameter("churros", cpf + "%")
				.getResultList();
	}

	public List<Object[]> agruparCidade() {
		return em.createNamedQuery("Cliente.contarPorCidade", Object[].class)
				.getResultList();
	}

}
