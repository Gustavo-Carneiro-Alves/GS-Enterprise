package br.com.fiap.dao.impl;

import java.util.List;

import javax.persistence.EntityManager;

import br.com.fiap.dao.CidadeDao;
import br.com.fiap.entity.Cidade;

public class CidadeDaoImpl extends GenericDaoImpl<Cidade,Integer> implements CidadeDao{

	public CidadeDaoImpl(EntityManager entityManager) {
		super(entityManager);
	}

	@SuppressWarnings("unchecked")
	public List<Cidade> buscarPorNumeroHabitantesEntre(Integer min, Integer max) {
		return em.createNativeQuery("select * from tb_ead_cidade where nr_habitantes "
				+ "between :i and :f", Cidade.class)
				.setParameter("i", min)
				.setParameter("f", max)
				.getResultList();
	}

}
