package br.com.fiap.dao;

import java.util.List;
import br.com.fiap.entity.Cidade;

public interface CidadeDao extends GenericDao<Cidade,Integer> {
	
	List<Cidade> buscarPorNumeroHabitantesEntre(Integer min, Integer max);

}
