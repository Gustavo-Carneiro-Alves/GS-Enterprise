package br.com.fiap.dao;

import br.com.fiap.entity.Transporte;

public interface TransporteDao extends GenericDao<Transporte,Integer>{

}
