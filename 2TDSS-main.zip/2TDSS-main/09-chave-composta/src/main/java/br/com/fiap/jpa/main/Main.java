package br.com.fiap.jpa.main;

import java.math.BigDecimal;
import java.time.LocalDateTime;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;

import br.com.fiap.jpa.dao.ConsultaDao;
import br.com.fiap.jpa.dao.MedicoDao;
import br.com.fiap.jpa.dao.PacienteDao;
import br.com.fiap.jpa.dao.impl.ConsultaDaoImpl;
import br.com.fiap.jpa.dao.impl.MedicoDaoImpl;
import br.com.fiap.jpa.dao.impl.PacienteDaoImpl;
import br.com.fiap.jpa.entity.Consulta;
import br.com.fiap.jpa.entity.Medico;
import br.com.fiap.jpa.entity.Paciente;
import br.com.fiap.jpa.exception.CommitException;
import br.com.fiap.jpa.singleton.EntityManagerFactorySingleton;

public class Main {
	
	//Cadastrar o m�dico, paciente e consulta
	public static void main(String[] args) {
		//Instanciar o m�dico
		Medico medico = new Medico();
		medico.setNome("Drauzio");
		medico.setEspecialidade("Geral");
		
		//Setar o salario e n�mero da conta do m�dico
		medico.setSalario(new BigDecimal("20000"));
		medico.setNumeroConta(254654);	
		
		//Setar o telefone e o e-mail
		medico.setTelefone(986521213);
		medico.setEmail("drauzio@globo.com");
		
		//Instanciar o paciente
		Paciente paciente = new Paciente();
		paciente.setNome("Pedro");
		paciente.setCpf("123.654.988-89");
		
		//Instanciar a consulta
		Consulta consulta = new Consulta();
		consulta.setMedico(medico);
		consulta.setPaciente(paciente);
										//ano, mes, dia, horas, minutos
		consulta.setData(LocalDateTime.of(2022, 7, 15, 10, 0));
		
		//Obter um entity manager
		EntityManagerFactory fabrica = EntityManagerFactorySingleton.getInstance();
		EntityManager em = fabrica.createEntityManager();
		
		//Instanciar o Dao do m�dico, consulta e paciente
		MedicoDao medicoDao = new MedicoDaoImpl(em);
		PacienteDao pacienteDao = new PacienteDaoImpl(em);
		ConsultaDao consultaDao = new ConsultaDaoImpl(em);
		
		//Cadastrar o m�dico
		medicoDao.cadastrar(medico);
		
		//Cadastrar o paciente
		pacienteDao.cadastrar(paciente);
		
		//Cadastrar a consulta
		consulta.setCodigo(0);
		consultaDao.cadastrar(consulta);
		
		//Commit
		try {
			consultaDao.commit();
		} catch (CommitException e) {
			e.printStackTrace();
		}
		
	}
}