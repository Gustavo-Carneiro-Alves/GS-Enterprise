package br.com.fiap.jpa.dao;

import br.com.fiap.jpa.entity.Consulta;
import br.com.fiap.jpa.entity.ConsultaPk;

public interface ConsultaDao extends GenericDao<Consulta, ConsultaPk> {

}
