package br.com.fiap.jpa.dao;

import br.com.fiap.jpa.entity.Paciente;

public interface PacienteDao extends GenericDao<Paciente, Integer> {

}
