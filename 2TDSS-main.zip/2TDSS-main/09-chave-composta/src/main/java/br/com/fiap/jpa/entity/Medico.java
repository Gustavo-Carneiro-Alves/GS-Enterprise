package br.com.fiap.jpa.entity;

import java.math.BigDecimal;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.SecondaryTable;
import javax.persistence.SecondaryTables;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@SecondaryTables({
	//Mapeia uma outra tabela no banco
	@SecondaryTable(name="TB_MEDICO_FINANCEIRO"),
	@SecondaryTable(name="TB_MEDICO_CONTATO")
})

@Entity
@Table(name="TB_MEDICO")
@SequenceGenerator(name="medico", sequenceName = "SQ_TB_MEDICO", allocationSize = 1)
public class Medico {

	@Id
	@Column(name="cd_medico")
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "medico")
	private Integer codigo;
	
	@Column(name="nr_telefone", nullable = false, table = "TB_MEDICO_CONTATO")
	private Integer telefone;
	
	@Column(name="ds_email", length = 80, table="TB_MEDICO_CONTATO")
	private String email;
	
	@Column(name="vl_salario", nullable = false, table = "TB_MEDICO_FINANCEIRO")
	private BigDecimal salario;
	
	@Column(name="nr_conta", nullable = false, table = "TB_MEDICO_FINANCEIRO")
	private Integer numeroConta;
	
	@Column(name="nm_medico", nullable = false, length = 80)
	private String nome;
	
	@Column(name="ds_especialidade", length = 40)
	private String especialidade;
	
	@OneToMany(mappedBy = "medico")
	private List<Consulta> consultas;

	public Integer getCodigo() {
		return codigo;
	}

	public void setCodigo(Integer codigo) {
		this.codigo = codigo;
	}

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public String getEspecialidade() {
		return especialidade;
	}

	public void setEspecialidade(String especialidade) {
		this.especialidade = especialidade;
	}

	public List<Consulta> getConsultas() {
		return consultas;
	}

	public void setConsultas(List<Consulta> consultas) {
		this.consultas = consultas;
	}

	public BigDecimal getSalario() {
		return salario;
	}

	public void setSalario(BigDecimal salario) {
		this.salario = salario;
	}

	public Integer getNumeroConta() {
		return numeroConta;
	}

	public void setNumeroConta(Integer numeroConta) {
		this.numeroConta = numeroConta;
	}

	public Integer getTelefone() {
		return telefone;
	}

	public void setTelefone(Integer telefone) {
		this.telefone = telefone;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}
	
}
