package br.com.fiap.jpa.dao;

import br.com.fiap.jpa.entity.Medico;

public interface MedicoDao extends GenericDao<Medico, Integer> {

}
