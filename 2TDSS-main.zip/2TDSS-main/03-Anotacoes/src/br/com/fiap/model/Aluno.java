package br.com.fiap.model;

import br.com.fiap.anotacao.Tabela;

@Tabela(nome = "TB_ALUNO")
public class Aluno {

}