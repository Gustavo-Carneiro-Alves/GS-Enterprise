package br.com.fiap.jpa.main;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;

import br.com.fiap.jpa.dao.SistemaDao;
import br.com.fiap.jpa.dao.impl.SistemaDaoImpl;
import br.com.fiap.jpa.entity.CasoTeste;
import br.com.fiap.jpa.entity.ItemTeste;
import br.com.fiap.jpa.entity.Sistema;
import br.com.fiap.jpa.entity.Usuario;
import br.com.fiap.jpa.exception.CommitException;
import br.com.fiap.jpa.singleton.EntityManagerFactorySingleton;

public class Cadastro {

	//Cadastrar com o cascade:
	public static void main(String[] args) {
		//Instanciar o Sistema com o nome
		Sistema sistema = new Sistema("RH");
		
		//Instanciar o Caso Teste com o nome e descri��o
		CasoTeste caso = new CasoTeste("Admiss�o", "Admiss�o de efetivo");
		
		//Instanciar o Item Teste com a descri��o
		ItemTeste item = new ItemTeste("Admitir um colaborador com sucesso");
		
		//Adicionar o item teste no caso teste
		caso.addItemTeste(item);
		
		//Adicionar o caso teste no sistema
		sistema.addCasoTeste(caso);
		
		//Instanciar um usu�rio
		Usuario usuario = new Usuario("Oswaldo");
		
		//Adicionar o item de teste no usu�rio
		usuario.getItensTeste().add(item);
		
		//Criar a lista de usu�rio e adicionar na lista
		List<Usuario> usuarios = new ArrayList<Usuario>();
		usuarios.add(usuario);
		
		//Adicionar a lista de usu�rio no item de teste
		item.setUsuarios(usuarios);
		
		//Cadastrar o sistema
		EntityManager em = EntityManagerFactorySingleton.getInstance().createEntityManager();
		SistemaDao dao = new SistemaDaoImpl(em);
		
		try {
			dao.cadastrar(sistema);
			dao.commit();
		}catch(CommitException e) {
			System.out.println(e.getMessage());
		}
		
	}
}
