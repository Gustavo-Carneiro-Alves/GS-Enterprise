package br.com.fiap.jpa.dao;

import br.com.fiap.jpa.entity.CasoTeste;

public interface CasoTesteDao extends GenericDao<CasoTeste, Integer>{

}
