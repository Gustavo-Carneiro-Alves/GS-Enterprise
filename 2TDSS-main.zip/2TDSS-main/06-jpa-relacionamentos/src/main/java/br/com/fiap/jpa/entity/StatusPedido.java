package br.com.fiap.jpa.entity;

public enum StatusPedido {

	ABERTO, CANCELADO, FINALIZADO, ESPERANDO_PAGAMENTO
	
}
