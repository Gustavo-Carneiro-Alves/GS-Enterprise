package br.com.fiap.jpa.dao;

import br.com.fiap.jpa.entity.Pedido;

public interface PedidoDao extends GenericDao<Pedido, Integer> {

}
