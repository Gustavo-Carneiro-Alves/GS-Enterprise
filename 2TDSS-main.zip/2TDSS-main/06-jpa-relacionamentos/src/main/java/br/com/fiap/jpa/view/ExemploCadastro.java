package br.com.fiap.jpa.view;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;

import br.com.fiap.jpa.dao.ClienteDao;
import br.com.fiap.jpa.dao.impl.ClienteDaoImpl;
import br.com.fiap.jpa.entity.Cliente;
import br.com.fiap.jpa.entity.NotaFiscal;
import br.com.fiap.jpa.entity.Pedido;
import br.com.fiap.jpa.entity.Produto;
import br.com.fiap.jpa.entity.StatusPedido;
import br.com.fiap.jpa.exception.CommitException;
import br.com.fiap.jpa.singleton.EntityManagerFactorySingleton;

public class ExemploCadastro {

	//Cadastrar o pedido e a nota fiscal
	public static void main(String[] args) {
		//Obter a f�brica e o entity manager
		EntityManagerFactory fabrica = EntityManagerFactorySingleton.getInstance();
		EntityManager em = fabrica.createEntityManager();
		
		try {
			//Instanciar o pedido (Criar o construtor com as informa��es que ser�o persistidas)
			Pedido pedido = new Pedido(LocalDateTime.now(), new BigDecimal("100"), StatusPedido.ABERTO);
			
			//Instanciar a nota fiscal (criar o construtor)
			NotaFiscal nota = new NotaFiscal(pedido, "2134641316", new BigDecimal("100"),
					LocalDateTime.now(), "123131546", new BigDecimal("40"));
			
			pedido.setNotaFiscal(nota);
			
			//Instanciar um pedido
			Pedido pedido2 = new Pedido(LocalDateTime.now(), new BigDecimal("15"), StatusPedido.ESPERANDO_PAGAMENTO);
			
			//Instanciar a nota fiscal do pedido
			NotaFiscal nota2 = new NotaFiscal(pedido2, "12313", new BigDecimal("15"),
					LocalDateTime.now(), "4654646", new BigDecimal("2"));
			
			pedido2.setNotaFiscal(nota2);
			
			//Instanciar o cliente
			Cliente cliente = new Cliente("Jo�ozinho", "123.234.234-22");
			
			//Adicionar os pedidos no cliente
			cliente.addPedido(pedido2);
			cliente.addPedido(pedido);
			
			//Instanciar dois produtos (Criar o construtor com os atributos pertinentes)
			Produto p1 = new Produto("Churros", "Doce de leite", new BigDecimal("15"));
			Produto p2 = new Produto("Refrigerante", "Sabor laranja", new BigDecimal("8"));
			
			//Criar uma lista de produtos e adicionar os produtos
			List<Produto> produtos = new ArrayList<Produto>();
			produtos.add(p1);
			produtos.add(p2);
			
			//Adicionar a lista de produtos no pedido
			pedido.setProdutos(produtos);
			pedido2.setProdutos(produtos);
			
			//Instanciar o clienteDao
			ClienteDao dao = new ClienteDaoImpl(em);
			
			//Cadastrar o cliente,  cliente cadastra o pedido e o pedido cadastra a nota em cascata
			dao.cadastrar(cliente);
			dao.commit();
			
		} catch (CommitException e) {
			System.out.println(e.getMessage());
		}
	}
}