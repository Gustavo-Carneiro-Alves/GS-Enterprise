package br.com.fiap.jpa.dao;

import br.com.fiap.jpa.entity.NotaFiscal;

public interface NotaFiscalDao extends GenericDao<NotaFiscal, Integer> {

}
