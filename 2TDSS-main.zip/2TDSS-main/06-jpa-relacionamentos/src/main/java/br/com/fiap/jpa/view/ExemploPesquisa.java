package br.com.fiap.jpa.view;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;

import br.com.fiap.jpa.dao.NotaFiscalDao;
import br.com.fiap.jpa.dao.impl.NotaFiscalDaoImpl;
import br.com.fiap.jpa.entity.NotaFiscal;
import br.com.fiap.jpa.exception.IdNotFoundException;
import br.com.fiap.jpa.singleton.EntityManagerFactorySingleton;

public class ExemploPesquisa {

	public static void main(String[] args) {
		//Obter a fabrica e entity manager
		EntityManagerFactory fabrica = EntityManagerFactorySingleton.getInstance();
		EntityManager em = fabrica.createEntityManager();
		
		//Instanciar o PedidoDao
		NotaFiscalDao dao = new NotaFiscalDaoImpl(em);
		try {
			//Pesquisar o pedido pela PK
			NotaFiscal nota = dao.buscar(1);
			
			//Exibir o valor do pedido
			System.out.println(nota.getNumero());
			
			//Exibir o n�mero da nota
			System.out.println(nota.getPedido().getValor());
			
			//Exibir o nome do cliente do pedido
			System.out.println(nota.getPedido().getCliente().getNome());
			
		}catch(IdNotFoundException e) {
			System.out.println(e.getMessage());
		}
		em.close();
		fabrica.close();
	}
}