package br.com.fiap.jpa.dao.impl;

import br.com.fiap.jpa.entity.NotaFiscal;

import javax.persistence.EntityManager;

import br.com.fiap.jpa.dao.NotaFiscalDao;

public class NotaFiscalDaoImpl 
				extends GenericDaoImpl<NotaFiscal, Integer>
											implements NotaFiscalDao {

	public NotaFiscalDaoImpl(EntityManager em) {
		super(em);
	}

}
