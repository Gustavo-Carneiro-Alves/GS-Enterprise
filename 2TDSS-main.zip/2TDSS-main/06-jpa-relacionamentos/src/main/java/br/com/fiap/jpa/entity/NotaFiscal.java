package br.com.fiap.jpa.entity;

import java.math.BigDecimal;
import java.time.LocalDateTime;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity
@Table(name="TB_NOTA_FISCAL")
@SequenceGenerator(name="nota", sequenceName = "SQ_TB_NOTA_FISCAL", allocationSize = 1)
public class NotaFiscal {

	@Id
	@Column(name="cd_nota_fiscal")
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "nota")
	private Integer codigo;
	
	//Relacionamento 1:1
	@OneToOne(cascade = CascadeType.ALL, fetch = FetchType.LAZY) 
	@JoinColumn(name = "cd_pedido", nullable = false)
	private Pedido pedido;
	
	@Column(name="nr_nota", length = 40)
	private String numero;
	
	@Column(name="vl_nota", scale = 2, precision = 10, nullable = false)
	private BigDecimal valor;
	
	@Column(name="dt_emissao")
	private LocalDateTime dataEmissao;
	
	@Column(name="cd_verificacao", length = 40, nullable = false)
	private String codigoVerificacao;
	
	@Column(name="vl_imposto", scale = 2, precision = 10)
	private BigDecimal valorImposto;
	
	public NotaFiscal() {}

	public NotaFiscal(Pedido pedido, String numero, 
			BigDecimal valor, LocalDateTime dataEmissao,
			String codigoVerificacao, BigDecimal valorImposto) {
		this.pedido = pedido;
		this.numero = numero;
		this.valor = valor;
		this.dataEmissao = dataEmissao;
		this.codigoVerificacao = codigoVerificacao;
		this.valorImposto = valorImposto;
	}

	public Integer getCodigo() {
		return codigo;
	}

	public void setCodigo(Integer codigo) {
		this.codigo = codigo;
	}

	public String getNumero() {
		return numero;
	}

	public void setNumero(String numero) {
		this.numero = numero;
	}

	public BigDecimal getValor() {
		return valor;
	}

	public void setValor(BigDecimal valor) {
		this.valor = valor;
	}

	public LocalDateTime getDataEmissao() {
		return dataEmissao;
	}

	public void setDataEmissao(LocalDateTime dataEmissao) {
		this.dataEmissao = dataEmissao;
	}

	public String getCodigoVerificacao() {
		return codigoVerificacao;
	}

	public void setCodigoVerificacao(String codigoVerificacao) {
		this.codigoVerificacao = codigoVerificacao;
	}

	public BigDecimal getValorImposto() {
		return valorImposto;
	}

	public void setValorImposto(BigDecimal valorImposto) {
		this.valorImposto = valorImposto;
	}

	public Pedido getPedido() {
		return pedido;
	}

	public void setPedido(Pedido pedido) {
		this.pedido = pedido;
	}
	
}
