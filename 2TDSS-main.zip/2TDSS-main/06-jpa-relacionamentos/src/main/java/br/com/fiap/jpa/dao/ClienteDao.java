package br.com.fiap.jpa.dao;

import br.com.fiap.jpa.entity.Cliente;

public interface ClienteDao extends GenericDao<Cliente, Integer> {

}
