package br.com.fiap.jpa.entity;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity
@Table(name="TB_PEDIDO")
@SequenceGenerator(name="pedido", sequenceName = "SQ_TB_PEDIDO", allocationSize = 1)
public class Pedido {

	@Id
	@Column(name="cd_pedido")
	@GeneratedValue(generator = "pedido", strategy = GenerationType.SEQUENCE)
	private Integer codigo;
	
	@OneToOne(mappedBy = "pedido", cascade = CascadeType.PERSIST, fetch = FetchType.EAGER)
	private NotaFiscal notaFiscal;
	
	//Relacionamento N:1
	@ManyToOne
	@JoinColumn(name="cd_cliente", nullable = false)
	private Cliente cliente;
	
	//Relacionamento N:M
	@ManyToMany(cascade = CascadeType.PERSIST)
	@JoinTable(name="TB_ITEM_PEDIDO", 
			joinColumns = @JoinColumn(name = "cd_pedido"),
			inverseJoinColumns = @JoinColumn(name = "cd_produto"))
	private List<Produto> produtos;
	
	@Column(name="dt_pedido")
	private LocalDateTime data;
	
	@Column(name="vl_pedido", nullable = false, precision = 10, scale = 2)
	private BigDecimal valor;
	
	@Enumerated(EnumType.STRING)
	@Column(name="st_pedido", length = 20)
	private StatusPedido status;
	
	public Pedido() {}

	public Pedido(LocalDateTime data, BigDecimal valor, StatusPedido status) {
		this.data = data;
		this.valor = valor;
		this.status = status;
	}

	public Integer getCodigo() {
		return codigo;
	}

	public void setCodigo(Integer codigo) {
		this.codigo = codigo;
	}

	public LocalDateTime getData() {
		return data;
	}

	public void setData(LocalDateTime data) {
		this.data = data;
	}

	public BigDecimal getValor() {
		return valor;
	}

	public void setValor(BigDecimal valor) {
		this.valor = valor;
	}

	public StatusPedido getStatus() {
		return status;
	}

	public void setStatus(StatusPedido status) {
		this.status = status;
	}

	public NotaFiscal getNotaFiscal() {
		return notaFiscal;
	}

	public void setNotaFiscal(NotaFiscal notaFiscal) {
		this.notaFiscal = notaFiscal;
	}

	public Cliente getCliente() {
		return cliente;
	}

	public void setCliente(Cliente cliente) {
		this.cliente = cliente;
	}

	public List<Produto> getProdutos() {
		return produtos;
	}

	public void setProdutos(List<Produto> produtos) {
		this.produtos = produtos;
	}
	
}
