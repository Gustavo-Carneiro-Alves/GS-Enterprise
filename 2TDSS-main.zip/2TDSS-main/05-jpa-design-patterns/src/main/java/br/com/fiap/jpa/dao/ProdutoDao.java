package br.com.fiap.jpa.dao;

import br.com.fiap.jpa.entity.Produto;

public interface ProdutoDao extends GenericDao<Produto, Integer> {

	
}