package br.com.fiap.revisao.model;

public enum OrigemAlimento {

	ANIMAL, VEGETAL, MINERAL //, OUTRAS_ORIGENS
	
}