package br.com.fiap.jpa.main;

import java.time.LocalDate;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;

import br.com.fiap.jpa.dao.PessoaDao;
import br.com.fiap.jpa.dao.impl.PessoaDaoImpl;
import br.com.fiap.jpa.entity.Pessoa;
import br.com.fiap.jpa.entity.PessoaFisica;
import br.com.fiap.jpa.entity.PessoaJuridica;
import br.com.fiap.jpa.exception.CommitException;
import br.com.fiap.jpa.singleton.EntityManagerFactorySingleton;

public class Main {

	//Cadastrar uma Pessoa, PessoaFisica e PessoaJuridica
	public static void main(String[] args) {
		//Instanciar uma Pessoa
		Pessoa pessoa = new Pessoa();
		pessoa.setNome("Matheus");
		pessoa.setEmail("matheus@fiap.com.br");
		
		//Instanciar uma Pessoa Fisica
		PessoaFisica pf = new PessoaFisica();
		pf.setNome("Oswaldo");
		pf.setEmail("oswaldo@fiap.com.br");
		pf.setDataNascimento(LocalDate.of(1998, 10, 20));
		pf.setCpf("546.654.655-55");
		
		//Instanciar uma Pessoa Jur�dica
		PessoaJuridica pj = new PessoaJuridica();
		pj.setNome("FIAP");
		pj.setEmail("contato@fiap.com.br");
		pj.setCnpj("23.231.313/0001-56");
		pj.setRazaoSocial("VSTP Educa��o Ltda.");
		
		//Instanciar a PessoaDao
		EntityManagerFactory fabrica = EntityManagerFactorySingleton.getInstance();
		EntityManager em = fabrica.createEntityManager();
		PessoaDao dao = new PessoaDaoImpl(em);
		
		//Cadastrar
		dao.cadastrar(pessoa);
		dao.cadastrar(pj);
		dao.cadastrar(pf);
		
		//Commit
		try {
			dao.commit();
		} catch (CommitException e) {
			e.printStackTrace();
		}
		//Sucesso!
	}
}