package br.com.fiap.jpa.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;

//@DiscriminatorValue("PJ")

@Table(name="TB_PESSOA_JURIDICA")

@Entity
public class PessoaJuridica extends Pessoa {

	@Column(name="nr_cnpj")
	private String cnpj;
	
	@Column(name="nm_razao_social")
	private String razaoSocial;

	public String getCnpj() {
		return cnpj;
	}

	public void setCnpj(String cnpj) {
		this.cnpj = cnpj;
	}

	public String getRazaoSocial() {
		return razaoSocial;
	}

	public void setRazaoSocial(String razaoSocial) {
		this.razaoSocial = razaoSocial;
	}
	
}
