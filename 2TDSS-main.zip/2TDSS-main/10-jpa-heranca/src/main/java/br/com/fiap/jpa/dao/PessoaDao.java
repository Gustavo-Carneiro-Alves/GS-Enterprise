package br.com.fiap.jpa.dao;

import br.com.fiap.jpa.entity.Pessoa;

public interface PessoaDao extends GenericDao<Pessoa, Integer>{

}
