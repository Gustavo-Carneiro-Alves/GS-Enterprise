package aplicacao;

import java.math.BigDecimal;
import java.util.Calendar;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;

import dao.AcessorioDao;
import dao.DestribuidoraDao;
import dao.DonoDao;
import dao.JogoDao;
import dao.impl.AcessorioDaoImpl;
import dao.impl.DestribuidoraDaoImpl;
import dao.impl.DonoDaoImpl;
import dao.impl.JogoDaoImpl;
import dominio.Acessorio;
import dominio.Destribuidora;
import dominio.Dono;
import dominio.Jogo;
import dominio.TipoJogo;
import exception.CommitException;
import exception.IdNotFoundException;
import singleton.EntityManagerFactorySingleton;

public class Exemplo2 {
	
	public static void main(String[] args) throws CommitException, IdNotFoundException {
		
		//Instanciar os Dao
		EntityManagerFactory fabrica = EntityManagerFactorySingleton.getInstance();
		EntityManager em = fabrica.createEntityManager();
		
		JogoDao dao = new JogoDaoImpl(em);
		AcessorioDao dao2 = new AcessorioDaoImpl(em);
		DestribuidoraDao dao3 = new DestribuidoraDaoImpl(em); 
		DonoDao dao4 = new DonoDaoImpl(em);
		
		dao.buscar(1L);
		
		/*
		Destribuidora destribuidora = new Destribuidora();
		destribuidora.setNome("2K");
		destribuidora.setEmail("2k@email");
		destribuidora.setTelefone("(00) 4567-8910");
		*/
		
		Destribuidora destribuidora2 = new Destribuidora();
		destribuidora2.setNome("Valve");
		destribuidora2.setEmail("Valve@email");
		destribuidora2.setTelefone("(00) 1111-1111");
		dao3.cadastrar(destribuidora2);
		
		/*
		Destribuidora destribuidora3 = new Destribuidora();
		destribuidora3.setNome("EspartanGames");
		destribuidora3.setEmail("EspartanGames@email");
		destribuidora3.setTelefone("(75) 2222-2222");
		*/
		
		Dono dono = new Dono();
		dono.setNome("Jo�o das Couves");
		dono.setTelefone("(34) 1234-5678");
		dao4.cadastrar(dono);

		
		Acessorio mapa = new Acessorio();
		mapa.setDescricao("Mapa f�sico do jogo");

		Acessorio actionFigure = new Acessorio();
		actionFigure.setDescricao("Action Figure do jogo");

		//Acessorio ost = new Acessorio();
		//ost.setDescricao("OST do jogo");
		
		dao2.cadastrar(mapa);
		dao2.cadastrar(actionFigure);

		
		///*
		// parte iii - Usado data e CLOB
		StringBuilder especificacoes = new StringBuilder();
		especificacoes.append("Jogo em excelente estado.\n");
		especificacoes.append("Vers�o f�sica, sem mapa.\n");
		especificacoes.append("Primeiro dono, com embalagem lacrada ");
		especificacoes.append("e todas as normas de qualidade cumpridas.\n");
		especificacoes.append("N�o aceita reembolso.");
		
		Jogo jogo = new Jogo();

		jogo.setDesenvolvedora("CD");
		jogo.setNome("Steampunk 1650");
		jogo.setAnoLancamento(2077);
		jogo.setNota(99);
		jogo.setValor(new BigDecimal(200));
		jogo.setTipoJogo(TipoJogo.FPS);
		jogo.setEspecificacoes(especificacoes.toString());
		jogo.setDataCadastro(Calendar.getInstance());
		jogo.setDono(dono);
		jogo.setDestribuidora(destribuidora2);
		jogo.getAcessorios().add(mapa);
		jogo.getAcessorios().add(actionFigure);
				
		//Cadastrar
		dao.cadastrar(jogo);
		

		
		
		
		
		//Commit
		try {
			dao.commit();
			dao2.commit();
			dao3.commit();
			dao4.commit();
		} catch (CommitException e) {
			e.printStackTrace();
		}
		//Sucesso!
		
	}
	
}
