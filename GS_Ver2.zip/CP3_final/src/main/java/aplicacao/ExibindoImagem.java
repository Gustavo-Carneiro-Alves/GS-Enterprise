package aplicacao;

import java.awt.image.BufferedImage;
import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.math.BigDecimal;
import java.nio.file.FileSystems;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Calendar;

import javax.imageio.ImageIO;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.swing.ImageIcon;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import dominio.Acessorio;
import dominio.Destribuidora;
import dominio.Dono;
import dominio.Jogo;
import dominio.TipoJogo;

public class ExibindoImagem {

	public static void main(String[] args) throws IOException {

		// L� bytes do arquivo da imagem
		Path path = FileSystems.getDefault().getPath("arquivos-extras/skyrim2.jpg");
		byte[] foto = Files.readAllBytes(path);

		EntityManagerFactory emf = Persistence.createEntityManagerFactory("loja-veiculos");
		EntityManager em = emf.createEntityManager();

		em.getTransaction().begin(); // h� a necessidade de se fazer uma transa��o ao inserir algo no bd
		
		Dono dono = new Dono();
		dono.setNome("Juliana");
		dono.setTelefone("(34) 8765-4321");
		em.persist(dono);
		
		Destribuidora destribuidora = new Destribuidora();
		destribuidora.setNome("devolver");
		destribuidora.setEmail("devolver@email");
		destribuidora.setTelefone("(00) 4567-8910");
		em.persist(destribuidora);
		
		Acessorio mapa = new Acessorio();
		mapa.setDescricao("Mapa f�sico do jogo");
		em.persist(mapa);
		Acessorio actionFigure = new Acessorio();
		actionFigure.setDescricao("Action Figure do jogo");
		em.persist(actionFigure);
		Acessorio ost = new Acessorio();
		ost.setDescricao("OST do jogo");
		em.persist(ost);
		
		// /*
		

		Jogo jogo = new Jogo();
		jogo.setDesenvolvedora("Bethesda");
		jogo.setNome("Skyrim 2");
		jogo.setAnoLancamento(2097);
		jogo.setNota(88);
		jogo.setValor(new BigDecimal(300));
		jogo.setTipoJogo(TipoJogo.RPG);
		jogo.setFoto(foto);
		jogo.setDataCadastro(Calendar.getInstance());
		jogo.setDono(dono);
		jogo.setDestribuidora(destribuidora);
		jogo.getAcessorios().add(mapa);
		jogo.getAcessorios().add(actionFigure);
		
		em.persist(jogo);
		em.getTransaction().commit();
		// */

		//em.detach(jogo);
		Jogo jogo2 = em.find(Jogo.class, jogo.getCodigo());
		if (jogo2.getFoto() != null) {
			BufferedImage img = ImageIO.read(new ByteArrayInputStream(jogo2.getFoto()));
			JOptionPane.showMessageDialog(null, new JLabel(new ImageIcon(img)));
		} else {
			System.out.println("Jogo n�o possui foto.");
		}

		System.out.println("pronto!");
		em.close(); // fechando...
		emf.close();
	}

}
