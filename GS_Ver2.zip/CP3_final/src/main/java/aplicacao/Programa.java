package aplicacao;

import java.math.BigDecimal;
import java.util.Calendar;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.Query;

import dominio.Acessorio;
import dominio.Destribuidora;
import dominio.Dono;
import dominio.Jogo;
import dominio.TipoJogo;

public class Programa {

	@SuppressWarnings("unchecked")
	public static void main(String[] args) {

		EntityManagerFactory emf = Persistence.createEntityManagerFactory("loja-veiculos");
		EntityManager em = emf.createEntityManager();

		///*
		System.out.println("");
		em.getTransaction().begin(); // h� a necessidade de se fazer uma transa��o ao inserir algo no bd		
		
		Destribuidora destribuidora = new Destribuidora();
		destribuidora.setNome("2K");
		destribuidora.setEmail("2k@email");
		destribuidora.setTelefone("(00) 4567-8910");
		em.persist(destribuidora);
		
		Destribuidora destribuidora2 = new Destribuidora();
		destribuidora2.setNome("Valve");
		destribuidora2.setEmail("Valve@email");
		destribuidora2.setTelefone("(00) 1111-1111");
		em.persist(destribuidora2);
		
		Destribuidora destribuidora3 = new Destribuidora();
		destribuidora3.setNome("EspartanGames");
		destribuidora3.setEmail("EspartanGames@email");
		destribuidora3.setTelefone("(75) 2222-2222");
		em.persist(destribuidora3);
		
		Dono dono = new Dono();
		dono.setNome("Jo�o das Couves");
		dono.setTelefone("(34) 1234-5678");
		em.persist(dono);
		
		Acessorio mapa = new Acessorio();
		mapa.setDescricao("Mapa f�sico do jogo");
		em.persist(mapa);
		Acessorio actionFigure = new Acessorio();
		actionFigure.setDescricao("Action Figure do jogo");
		em.persist(actionFigure);
		Acessorio ost = new Acessorio();
		ost.setDescricao("OST do jogo");
		em.persist(ost);
		
		///*
		// parte iii - Usado data e CLOB
		StringBuilder especificacoes = new StringBuilder();
		especificacoes.append("Jogo em excelente estado.\n");
		especificacoes.append("Vers�o f�sica, sem mapa.\n");
		especificacoes.append("Primeiro dono, com embalagem lacrada ");
		especificacoes.append("e todas as normas de qualidade cumpridas.\n");
		especificacoes.append("N�o aceita reembolso.");
		
		Jogo jogo = new Jogo();

		jogo.setDesenvolvedora("CD");
		jogo.setNome("Steampunk 1650");
		jogo.setAnoLancamento(2077);
		jogo.setNota(99);
		jogo.setValor(new BigDecimal(200));
		jogo.setTipoJogo(TipoJogo.FPS);
		jogo.setEspecificacoes(especificacoes.toString());
		jogo.setDataCadastro(Calendar.getInstance());
		jogo.setDono(dono);
		jogo.setDestribuidora(destribuidora2);
		jogo.getAcessorios().add(mapa);
		jogo.getAcessorios().add(actionFigure);
		
		
		em.persist(jogo);
		//*/// parte iii continua abaixo

		Jogo jogo3 = new Jogo();

		jogo3.setDesenvolvedora("EA");
		jogo3.setNome("FIFA");
		jogo3.setAnoLancamento(2019);
		jogo3.setNota(15);
		jogo3.setValor(new BigDecimal(400));
		jogo3.setTipoJogo(TipoJogo.FUTEBOL);
		jogo3.setEspecificacoes(especificacoes.toString());
		jogo3.setDataCadastro(Calendar.getInstance());
		jogo3.setDono(dono);
		jogo3.setDestribuidora(destribuidora3);
		jogo3.getAcessorios().add(mapa);
		jogo3.getAcessorios().add(ost);
		
		em.persist(jogo3);

		
		Jogo jogo8 = new Jogo();

		jogo8.setDesenvolvedora("From");
		jogo8.setNome("DS3");
		jogo8.setAnoLancamento(2018);
		jogo8.setNota(100);
		jogo8.setValor(new BigDecimal(200));
		jogo8.setTipoJogo(TipoJogo.RPG);
		jogo8.setEspecificacoes(especificacoes.toString());
		jogo8.setDataCadastro(Calendar.getInstance());
		jogo8.setDono(dono);
		jogo8.setDestribuidora(destribuidora);
		jogo.getAcessorios().add(mapa);
		jogo.getAcessorios().add(ost);
		jogo.getAcessorios().add(actionFigure);
		
		em.persist(jogo8);
			
		em.getTransaction().commit();
		System.out.println("");
		
				
		///*
		// parte iii - Usado data e CLOB (continua��o)
		System.out.println("");
		System.out.println("Pesquisa 1");
		em.detach(jogo);
		Jogo jogo2 = em.find(Jogo.class, jogo.getCodigo());
		System.out.println("Jogo: " + jogo2.getCodigo());
		System.out.println("Jogo: " + jogo2.getNome());
		System.out.println("-------");
		System.out.println(jogo2.getEspecificacoes());
		System.out.println("");
		//*/		
		
		
		
		
		///* Pesquisar todos
		
		System.out.println("");
		System.out.println("Pesquisa 2");
		
		Query query = em.createQuery("select v from Jogo v");
		
		List<Jogo> jogos = query.getResultList();
		for (Jogo jogo4 : jogos) {
			System.out.println(jogo4.getCodigo() + " - " 
					+ jogo4.getDesenvolvedora() + ", " 
					+ jogo4.getNome() + ", ano " 
					+ jogo4.getAnoLancamento() + " / nota: " 
					+ jogo4.getNota() + " por " 
					+ "R$"+ jogo4.getValor());
		}
		System.out.println("");
		 //*/
		
		///* Atualizar
		System.out.println("");
		em.getTransaction().begin();
		
		Jogo jogo6 = em.find(Jogo.class, jogo.getCodigo());
		
		System.out.println("");
		System.out.println("Atualizando");
		System.out.println("Valor atual: " + jogo6.getValor());
		jogo6.setValor(jogo6.getValor().add(new BigDecimal(50)));
		System.out.println("Novo valor: " + jogo6.getValor());

		em.getTransaction().commit();
		System.out.println("");
		
		//*/
		

		/* Remover
		
		System.out.println("");
		System.out.println("Excluindo o jogo 2");
		em.getTransaction().begin();
		Jogo jogo4 = em.find(Jogo.class, jogo3.getCodigo());
		em.remove(jogo4);
		em.getTransaction().commit();
		System.out.println("");
		
		*/
		


		
		

		System.out.println("pronto!");
		em.close(); // fechando...
		emf.close();

	}

}
