package aplicacao;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import dominio.Dono;
import dominio.Jogo;

public class BuscandoDono {

	public static void main(String[] args) {

		EntityManagerFactory emf = Persistence.createEntityManagerFactory("loja-veiculos");
		EntityManager em = emf.createEntityManager();

		

		Dono dono = em.find(Dono.class, 1L);
		
		System.out.println("Dono: " + dono.getNome());
		
		for (Jogo jogo : dono.getJogos()) {
		System.out.println("Jogo: " + jogo.getNome());
		}

		

		System.out.println("pronto!");
		em.close(); // fechando...
		emf.close();

	}

}
