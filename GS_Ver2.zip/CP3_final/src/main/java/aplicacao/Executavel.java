package aplicacao;

import java.io.IOException;
import java.nio.file.FileSystems;
import java.nio.file.Files;
import java.nio.file.Path;
import java.time.LocalDate;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;

import dao.MovimentacaoPortariaDao;
import dao.VisitanteDao;
import dao.impl.MovimentacaoPortariaDaoImpl;
import dao.impl.VisitanteDaoImpl;
import dominio.MovimentacaoPortaria;
import dominio.Visitante;
import exception.CommitException;
import exception.IdNotFoundException;
import singleton.EntityManagerFactorySingleton;

public class Executavel {

public static void main(String[] args) throws CommitException, IdNotFoundException, IOException {
		
		//Instanciar os Dao
		EntityManagerFactory fabrica = EntityManagerFactorySingleton.getInstance();
		EntityManager em = fabrica.createEntityManager();
		
		VisitanteDao visitanteDao = new VisitanteDaoImpl(em);
		MovimentacaoPortariaDao movimentacaoPortariaDao = new MovimentacaoPortariaDaoImpl(em); 
		
		
		StringBuilder especificacoes = new StringBuilder();
		especificacoes.append("Chegou cedo.\n");
		especificacoes.append("N�o parecia suspeito.\n");
		especificacoes.append("Conhecia um morador ");
		especificacoes.append("e cumpriu todos os requisitos.\n");
		especificacoes.append("Planeja passar alguns dias aqui.");
		
		MovimentacaoPortaria movimentacaoPortaria = new MovimentacaoPortaria(); 
		movimentacaoPortaria.setTp_movimentacao((byte) 1);
		movimentacaoPortaria.setData(LocalDate.of(2023, 12, 30));
		movimentacaoPortaria.setDs_resumida(especificacoes.toString());
		
		// L� bytes do arquivo da imagem
		Path path = FileSystems.getDefault().getPath("arquivos-extras/img.jpg");
		byte[] img_movimentacao = Files.readAllBytes(path);
		movimentacaoPortaria.setImg_movimentacao(img_movimentacao);
		
		movimentacaoPortariaDao.cadastrar(movimentacaoPortaria);
		
		
		
		
		
		Visitante visitante = new Visitante();
		visitante.setName("Adalberto Mariano");
		visitante.setDt_nasc(LocalDate.of(2000,02,01));
		visitante.setCPF(11122233304L);
		visitante.setRG(555666777L);
		visitante.setDg_RG((byte) 8);
		visitante.setDt_cad(LocalDate.now());
		
		visitanteDao.cadastrar(visitante);
		//System.out.println(visitanteDao.buscar(1L).getName());
		
		
		
		//Commit
		try {
			visitanteDao.commit();
			
		} catch (CommitException e) {
			e.printStackTrace();
		}
		//Sucesso!
		
	}
	
}
