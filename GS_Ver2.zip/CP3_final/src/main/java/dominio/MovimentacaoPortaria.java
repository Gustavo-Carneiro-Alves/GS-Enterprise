package dominio;

import java.time.LocalDate;
import java.util.Arrays;
import java.util.List;
import java.util.Objects;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Lob;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Table(name = "T_GCD_MOVIMENTACAO_PORTARIA")
public class MovimentacaoPortaria {

	

		@Id
		@GeneratedValue(strategy = GenerationType.IDENTITY)
		private Long id_movimentacao;
		@Column(name="tp_movimentacao", length = 1, nullable = false)
		private byte tp_movimentacao;
		@Column(name="dt_movimentacao", nullable = false)
		private LocalDate data;
		@Lob
		private String ds_resumida;
		@Lob
		private byte[] img_movimentacao;
		
		
		@OneToMany(mappedBy = "movimentacaoPortaria")
		private List<Visitante> visitantes;


		public MovimentacaoPortaria() {
			
		}


		public MovimentacaoPortaria(Long id_movimentacao, byte tp_movimentacao, LocalDate data, String ds_resumida,
				byte[] img_movimentacao, List<Visitante> visitantes) {
			super();
			this.id_movimentacao = id_movimentacao;
			this.tp_movimentacao = tp_movimentacao;
			this.data = data;
			this.ds_resumida = ds_resumida;
			this.img_movimentacao = img_movimentacao;
			this.visitantes = visitantes;
		}


		public Long getId_movimentacao() {
			return id_movimentacao;
		}


		public void setId_movimentacao(Long id_movimentacao) {
			this.id_movimentacao = id_movimentacao;
		}


		public byte getTp_movimentacao() {
			return tp_movimentacao;
		}


		public void setTp_movimentacao(byte tp_movimentacao) {
			this.tp_movimentacao = tp_movimentacao;
		}


		public LocalDate getData() {
			return data;
		}


		public void setData(LocalDate data) {
			this.data = data;
		}


		public String getDs_resumida() {
			return ds_resumida;
		}


		public void setDs_resumida(String ds_resumida) {
			this.ds_resumida = ds_resumida;
		}


		public byte[] getImg_movimentacao() {
			return img_movimentacao;
		}


		public void setImg_movimentacao(byte[] img_movimentacao) {
			this.img_movimentacao = img_movimentacao;
		}


		public List<Visitante> getVisitantes() {
			return visitantes;
		}


		public void setVisitantes(List<Visitante> visitantes) {
			this.visitantes = visitantes;
		}


		@Override
		public int hashCode() {
			final int prime = 31;
			int result = 1;
			result = prime * result + Arrays.hashCode(img_movimentacao);
			result = prime * result + Objects.hash(data, ds_resumida, id_movimentacao, tp_movimentacao, visitantes);
			return result;
		}


		@Override
		public boolean equals(Object obj) {
			if (this == obj)
				return true;
			if (obj == null)
				return false;
			if (getClass() != obj.getClass())
				return false;
			MovimentacaoPortaria other = (MovimentacaoPortaria) obj;
			return Objects.equals(data, other.data) && Objects.equals(ds_resumida, other.ds_resumida)
					&& Objects.equals(id_movimentacao, other.id_movimentacao)
					&& Arrays.equals(img_movimentacao, other.img_movimentacao)
					&& tp_movimentacao == other.tp_movimentacao && Objects.equals(visitantes, other.visitantes);
		}
		
		
	
}
