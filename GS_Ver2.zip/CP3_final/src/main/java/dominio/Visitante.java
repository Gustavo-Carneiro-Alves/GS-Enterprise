package dominio;


	import java.time.LocalDate;
import java.util.Arrays;
import java.util.Objects;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.Lob;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

	@Entity
	@Table(name = "T_GCD_VISITANTE")
	public class Visitante {

		
		
		@Id 
		@GeneratedValue(strategy = GenerationType.IDENTITY)
		private Long id_visitante;
		
		@Column(name = "nm_visitante", nullable = false, length=100)
		private String name;
		
		@Column(name = "dt_nasc", nullable = false)
		private LocalDate dt_nasc;
		
		@Column(name = "nr_cpf", nullable = true, length=12)
		private Long CPF;
		
		@Column(name = "nr_rg", nullable = true, length=11)
		private Long RG;
		
		@Column(name = "nm_digito_rg", nullable = true, length=1)
		private byte dg_RG;
		
		@Column(name = "dt_cadastro", nullable = false)
		private LocalDate dt_cad = LocalDate.now();
		
		@Lob
		private byte[] foto;

		
		
		@ManyToOne
		@JoinColumn(name = "id_movimentacao")
		private MovimentacaoPortaria movimentacaoPortaria;
		
		public Visitante() {
		
		}



		public Visitante(Long id_visitante, String name, LocalDate dt_nasc, Long cPF, Long rG, byte dg_RG,
				LocalDate dt_cad, byte[] foto) {
			super();
			this.id_visitante = id_visitante;
			this.name = name;
			this.dt_nasc = dt_nasc;
			CPF = cPF;
			RG = rG;
			this.dg_RG = dg_RG;
			this.dt_cad = dt_cad;
			this.foto = foto;
		}



		public Long getId_visitante() {
			return id_visitante;
		}



		public void setId_visitante(Long id_visitante) {
			this.id_visitante = id_visitante;
		}



		public String getName() {
			return name;
		}



		public void setName(String name) {
			this.name = name;
		}



		public LocalDate getDt_nasc() {
			return dt_nasc;
		}



		public void setDt_nasc(LocalDate dt_nasc) {
			this.dt_nasc = dt_nasc;
		}



		public Long getCPF() {
			return CPF;
		}



		public void setCPF(Long cPF) {
			CPF = cPF;
		}



		public Long getRG() {
			return RG;
		}



		public void setRG(Long rG) {
			RG = rG;
		}



		public byte getDg_RG() {
			return dg_RG;
		}



		public void setDg_RG(byte dg_RG) {
			this.dg_RG = dg_RG;
		}



		public LocalDate getDt_cad() {
			return dt_cad;
		}



		public void setDt_cad(LocalDate dt_cad) {
			this.dt_cad = dt_cad;
		}



		public byte[] getFoto() {
			return foto;
		}



		public void setFoto(byte[] foto) {
			this.foto = foto;
		}



		@Override
		public int hashCode() {
			final int prime = 31;
			int result = 1;
			result = prime * result + Arrays.hashCode(foto);
			result = prime * result + Objects.hash(CPF, RG, dg_RG, dt_cad, dt_nasc, id_visitante, name);
			return result;
		}



		@Override
		public boolean equals(Object obj) {
			if (this == obj)
				return true;
			if (obj == null)
				return false;
			if (getClass() != obj.getClass())
				return false;
			Visitante other = (Visitante) obj;
			return Objects.equals(CPF, other.CPF) && Objects.equals(RG, other.RG) && dg_RG == other.dg_RG
					&& Objects.equals(dt_cad, other.dt_cad) && Objects.equals(dt_nasc, other.dt_nasc)
					&& Arrays.equals(foto, other.foto) && Objects.equals(id_visitante, other.id_visitante)
					&& Objects.equals(name, other.name);
		}



		
		

		
		

		
		
	}