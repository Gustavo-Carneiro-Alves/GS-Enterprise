package dao;

import dominio.Dono;

public interface DonoDao extends GenericDao<Dono, Integer>{

}
