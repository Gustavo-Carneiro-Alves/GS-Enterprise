package dao.impl;

import javax.persistence.EntityManager;

import dao.AcessorioDao;
import dominio.Acessorio;

public class AcessorioDaoImpl extends GenericDaoImpl<Acessorio, Integer>
												implements AcessorioDao {

	public AcessorioDaoImpl(EntityManager em) {
		super(em);
	}

}
