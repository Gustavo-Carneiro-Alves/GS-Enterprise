package dao.impl;

import javax.persistence.EntityManager;

import dao.MovimentacaoPortariaDao;
import dominio.MovimentacaoPortaria;

public class MovimentacaoPortariaDaoImpl extends GenericDaoImpl<MovimentacaoPortaria, Long>
												implements MovimentacaoPortariaDao {

	public MovimentacaoPortariaDaoImpl(EntityManager em) {
		super(em);
	}

}
