package dao.impl;

import javax.persistence.EntityManager;

import dao.DonoDao;
import dominio.Dono;

public class DonoDaoImpl extends GenericDaoImpl<Dono, Integer>
												implements DonoDao {

	public DonoDaoImpl(EntityManager em) {
		super(em);
	}

}
