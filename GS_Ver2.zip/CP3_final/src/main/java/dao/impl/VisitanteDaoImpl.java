package dao.impl;

import javax.persistence.EntityManager;

import dao.VisitanteDao;
import dominio.Visitante;

public class VisitanteDaoImpl extends GenericDaoImpl<Visitante, Long>
												implements VisitanteDao {

	public VisitanteDaoImpl(EntityManager em) {
		super(em);
	}

}
