package dao.impl;

import javax.persistence.EntityManager;

import dao.JogoDao;
import dominio.Jogo;

public class JogoDaoImpl extends GenericDaoImpl<Jogo, Long>
												implements JogoDao {

	public JogoDaoImpl(EntityManager em) {
		super(em);
	}

}
