package dao.impl;

import javax.persistence.EntityManager;

import dao.DestribuidoraDao;
import dominio.Destribuidora;

public class DestribuidoraDaoImpl extends GenericDaoImpl<Destribuidora, Integer>
												implements DestribuidoraDao {

	public DestribuidoraDaoImpl(EntityManager em) {
		super(em);
	}

}
