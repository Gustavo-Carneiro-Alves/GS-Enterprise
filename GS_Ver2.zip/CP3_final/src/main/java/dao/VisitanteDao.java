package dao;

import dominio.Visitante;

public interface VisitanteDao extends GenericDao<Visitante, Long>{

}
