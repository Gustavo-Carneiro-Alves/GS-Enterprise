package dao;

import exception.CommitException;
import exception.IdNotFoundException;

//	GenericDao<Cliente,String>
//T -> tipo da entidade
//k -> tipo da chave prim�ria

public interface GenericDao<T,K> {

	void cadastrar(T entidade);
	
	void atualizar(T entidade);
	
	T buscar(K id) throws IdNotFoundException;
	
	void deletar(K id) throws IdNotFoundException;
	
	void commit() throws CommitException;
	
}