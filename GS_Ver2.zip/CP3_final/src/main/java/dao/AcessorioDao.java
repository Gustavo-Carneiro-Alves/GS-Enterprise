package dao;

import dominio.Acessorio;

public interface AcessorioDao extends GenericDao<Acessorio, Integer>{

}
