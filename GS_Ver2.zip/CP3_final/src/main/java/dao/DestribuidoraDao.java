package dao;

import dominio.Destribuidora;

public interface DestribuidoraDao extends GenericDao<Destribuidora, Integer>{

}
