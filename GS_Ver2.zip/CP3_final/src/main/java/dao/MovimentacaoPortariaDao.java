package dao;

import dominio.MovimentacaoPortaria;

public interface MovimentacaoPortariaDao extends GenericDao<MovimentacaoPortaria, Long>{

}
