package dao;

import dominio.Jogo;

public interface JogoDao extends GenericDao<Jogo, Long>{

}
